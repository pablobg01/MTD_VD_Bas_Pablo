import { Component } from '@angular/core';
import { ScatterPlotComponent } from './scatter-plot/scatter-plot';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    ScatterPlotComponent
  ],
 template: `
  <h1>Scatter Plot Example</h1>
  <app-scatter-plot></app-scatter-plot>
`,
styles: []

})
export class AppComponent {
  title = 'bas-scatter-app';
}