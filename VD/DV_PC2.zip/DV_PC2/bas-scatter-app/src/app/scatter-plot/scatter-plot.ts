import { Component, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as Plotly from 'plotly.js-dist';

@Component({
  selector: 'app-scatter-plot',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div #plotElement style="width: 600px; height: 400px;"></div>
  `,
  styles: []
})
export class ScatterPlotComponent implements AfterViewInit {
  @ViewChild('plotElement') plotElement!: ElementRef;

  constructor() {}

  ngAfterViewInit(): void {
    this.createScatterPlot();
  }

  createScatterPlot(): void {
    const trace1 = {
      x: [1, 2, 3, 4, 5],
      y: [10, 15, 7, 17, 12],
      mode: 'markers',
      type: 'scatter',
      name: 'Sample Data 1'
    };

    const trace2 = {
      x: [1.5, 2.5, 3.5, 4.5, 5.5],
      y: [5, 12, 9, 14, 10],
      mode: 'lines+markers',
      type: 'scatter',
      name: 'Sample Data 2'
    };

    const data = [trace1, trace2];

    const layout = {
      title: 'My Scatter Plot',
      xaxis: { title: 'X Axis' },
      yaxis: { title: 'Y Axis' }
    };

    Plotly.newPlot(this.plotElement.nativeElement, data, layout);
  }
}