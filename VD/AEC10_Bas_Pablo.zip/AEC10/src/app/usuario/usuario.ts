import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Usuario } from '../usuario.model';

@Component({
  selector: 'app-usuario',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './usuario.html',
  styleUrls: ['./usuario.css']
})
export class UsuarioComponent {
  @Input() user!: Usuario;
  @Output() saludar = new EventEmitter<string>();
  @Output() toggle = new EventEmitter<number>();

  enviarSaludo() {
    this.saludar.emit(`¡Hola! Soy ${this.user.nombre}.`);
  }

  toggleEstado() {
    this.toggle.emit(this.user.id);
  }
}
