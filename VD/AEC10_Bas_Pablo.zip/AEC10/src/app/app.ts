import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Usuario } from './usuario.model';
import { UsuarioComponent } from './usuario/usuario';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, UsuarioComponent],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {
  usuarios: Usuario[] = [    
    { id: 1, nombre: 'Alice', activo: true },
    { id: 2, nombre: 'Bob', activo: false },
    { id: 3, nombre: 'Carla', activo: true }
  ];

  saludoRecibido: string = '';

  recibirSaludo(mensaje: string) {
    this.saludoRecibido = mensaje;
  }

  cambiarEstadoUsuario(id: number) {
    const usuario = this.usuarios.find(u => u.id === id);
    if (usuario) {
      usuario.activo = !usuario.activo;
    }
  }
}

