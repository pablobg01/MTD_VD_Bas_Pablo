export interface Usuario {
  id: number;
  nombre: string;
  activo: boolean;
}
