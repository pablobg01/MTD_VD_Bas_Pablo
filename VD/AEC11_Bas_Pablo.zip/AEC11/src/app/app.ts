import { Component } from '@angular/core';
import { UsuariosComponent } from './componentes/usuarios/usuarios.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [UsuariosComponent],
  template: `
    <app-usuarios></app-usuarios>
  `
})
export class AppComponent {}
